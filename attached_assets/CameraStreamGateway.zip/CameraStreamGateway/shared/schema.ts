import { pgTable, text, serial, integer, boolean, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Camera table definition
export const cameras = pgTable("cameras", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  lensCount: integer("lens_count").notNull(),
  streamingResolution: integer("streaming_resolution").notNull(),
  frameRate: integer("frame_rate").notNull(),
  storagedays: integer("storage_days").notNull(),
  recordingResolution: integer("recording_resolution").notNull(),
  createdAt: text("created_at").notNull().default(new Date().toISOString()),
});

// Gateway table definition
export const gateways = pgTable("gateways", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // '8ch' or '16ch'
  maxStreams: integer("max_streams").notNull(),
  maxThroughput: integer("max_throughput").notNull(),
  maxStorage: integer("max_storage").notNull(),
});

// Camera streams table for assignment to gateways
export const cameraStreams = pgTable("camera_streams", {
  id: serial("id").primaryKey(),
  cameraId: integer("camera_id").notNull(),
  gatewayId: integer("gateway_id"),
  streamIndex: integer("stream_index").notNull(),
  throughput: real("throughput").notNull(),
  storage: real("storage").notNull(),
});

// Schemas for insert operations
export const insertCameraSchema = createInsertSchema(cameras).omit({
  id: true,
  createdAt: true
});

export const insertGatewaySchema = createInsertSchema(gateways).omit({
  id: true
});

export const insertCameraStreamSchema = createInsertSchema(cameraStreams).omit({
  id: true
});

// BitRate table as a constant object
export const BITRATE_TABLE = {
  1: 1.5,
  2: 2.0,
  4: 2.5,
  5: 2.8,
  6: 3.0,
  8: 3.5,
  12: 4.0
};

// Custom zod schemas for frontend validation
export const cameraFormSchema = z.object({
  name: z.string().min(1, "Camera name is required"),
  lensCount: z.coerce.number().int().min(1).max(4),
  streamingResolution: z.coerce.number().int(),
  frameRate: z.coerce.number().int().min(1).max(60),
  storageDays: z.coerce.number().int().min(1).max(365),
  recordingResolution: z.coerce.number().int(),
  sameAsStreaming: z.boolean().default(true)
});

// Types for our application
export type InsertCamera = z.infer<typeof insertCameraSchema>;
export type Camera = typeof cameras.$inferSelect;

export type InsertGateway = z.infer<typeof insertGatewaySchema>;
export type Gateway = typeof gateways.$inferSelect;

export type InsertCameraStream = z.infer<typeof insertCameraStreamSchema>;
export type CameraStream = typeof cameraStreams.$inferSelect;

export type CameraFormData = z.infer<typeof cameraFormSchema>;

import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { cameraFormSchema, insertCameraSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes with /api prefix
  
  // Camera routes
  app.get("/api/cameras", async (_req: Request, res: Response) => {
    try {
      const cameras = await storage.getAllCameras();
      res.json(cameras);
    } catch (error) {
      res.status(500).json({ message: "Error fetching cameras" });
    }
  });

  app.get("/api/cameras/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid camera ID" });
      }
      
      const camera = await storage.getCamera(id);
      if (!camera) {
        return res.status(404).json({ message: "Camera not found" });
      }
      
      res.json(camera);
    } catch (error) {
      res.status(500).json({ message: "Error fetching camera" });
    }
  });

  app.post("/api/cameras", async (req: Request, res: Response) => {
    try {
      // Validate incoming data
      const validatedData = insertCameraSchema.parse(req.body);
      
      // Create camera
      const camera = await storage.createCamera(validatedData);
      res.status(201).json(camera);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid camera data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Error creating camera" });
    }
  });

  app.put("/api/cameras/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid camera ID" });
      }
      
      // Validate incoming data
      const validatedData = insertCameraSchema.partial().parse(req.body);
      
      // Update camera
      const camera = await storage.updateCamera(id, validatedData);
      if (!camera) {
        return res.status(404).json({ message: "Camera not found" });
      }
      
      res.json(camera);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid camera data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Error updating camera" });
    }
  });

  app.delete("/api/cameras/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid camera ID" });
      }
      
      const success = await storage.deleteCamera(id);
      if (!success) {
        return res.status(404).json({ message: "Camera not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting camera" });
    }
  });

  // Gateway routes
  app.get("/api/gateways", async (_req: Request, res: Response) => {
    try {
      const gateways = await storage.getAllGateways();
      res.json(gateways);
    } catch (error) {
      res.status(500).json({ message: "Error fetching gateways" });
    }
  });

  // Camera Stream routes
  app.get("/api/camera-streams", async (_req: Request, res: Response) => {
    try {
      const cameraStreams = await storage.getAllCameraStreams();
      res.json(cameraStreams);
    } catch (error) {
      res.status(500).json({ message: "Error fetching camera streams" });
    }
  });

  app.get("/api/camera-streams/gateway/:gatewayId", async (req: Request, res: Response) => {
    try {
      const gatewayId = parseInt(req.params.gatewayId);
      if (isNaN(gatewayId)) {
        return res.status(400).json({ message: "Invalid gateway ID" });
      }
      
      const cameraStreams = await storage.getCameraStreamsByGateway(gatewayId);
      res.json(cameraStreams);
    } catch (error) {
      res.status(500).json({ message: "Error fetching camera streams" });
    }
  });

  app.post("/api/camera-streams", async (req: Request, res: Response) => {
    try {
      const cameraStream = await storage.createCameraStream(req.body);
      res.status(201).json(cameraStream);
    } catch (error) {
      res.status(500).json({ message: "Error creating camera stream" });
    }
  });

  app.patch("/api/camera-streams/:id/gateway/:gatewayId", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const gatewayId = parseInt(req.params.gatewayId);
      
      if (isNaN(id) || isNaN(gatewayId)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const cameraStream = await storage.updateCameraStreamGateway(id, gatewayId);
      if (!cameraStream) {
        return res.status(404).json({ message: "Camera stream not found" });
      }
      
      res.json(cameraStream);
    } catch (error) {
      res.status(500).json({ message: "Error updating camera stream" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

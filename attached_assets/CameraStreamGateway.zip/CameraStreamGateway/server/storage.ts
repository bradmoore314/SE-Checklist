import { cameras, gateways, cameraStreams, type Camera, type InsertCamera, type Gateway, type InsertGateway, type CameraStream, type InsertCameraStream } from "@shared/schema";

// modify the interface with any CRUD methods
export interface IStorage {
  // Camera operations
  getAllCameras(): Promise<Camera[]>;
  getCamera(id: number): Promise<Camera | undefined>;
  createCamera(camera: InsertCamera): Promise<Camera>;
  updateCamera(id: number, camera: Partial<InsertCamera>): Promise<Camera | undefined>;
  deleteCamera(id: number): Promise<boolean>;

  // Gateway operations
  getAllGateways(): Promise<Gateway[]>;
  getGateway(id: number): Promise<Gateway | undefined>;
  createGateway(gateway: InsertGateway): Promise<Gateway>;

  // Camera Stream operations
  getAllCameraStreams(): Promise<CameraStream[]>;
  getCameraStreamsByGateway(gatewayId: number): Promise<CameraStream[]>;
  createCameraStream(cameraStream: InsertCameraStream): Promise<CameraStream>;
  updateCameraStreamGateway(id: number, gatewayId: number): Promise<CameraStream | undefined>;
}

export class MemStorage implements IStorage {
  private cameras: Map<number, Camera>;
  private gateways: Map<number, Gateway>;
  private cameraStreams: Map<number, CameraStream>;
  private cameraIdCounter: number;
  private gatewayIdCounter: number;
  private cameraStreamIdCounter: number;

  constructor() {
    this.cameras = new Map();
    this.gateways = new Map();
    this.cameraStreams = new Map();
    this.cameraIdCounter = 1;
    this.gatewayIdCounter = 1;
    this.cameraStreamIdCounter = 1;

    // Initialize with default gateways
    this.createGateway({
      type: '8ch',
      maxStreams: 8,
      maxThroughput: 320,
      maxStorage: 6
    });
    
    this.createGateway({
      type: '16ch',
      maxStreams: 16,
      maxThroughput: 640,
      maxStorage: 12
    });
  }

  // Camera operations
  async getAllCameras(): Promise<Camera[]> {
    return Array.from(this.cameras.values());
  }

  async getCamera(id: number): Promise<Camera | undefined> {
    return this.cameras.get(id);
  }

  async createCamera(camera: InsertCamera): Promise<Camera> {
    const id = this.cameraIdCounter++;
    const newCamera: Camera = { ...camera, id, createdAt: new Date().toISOString() };
    this.cameras.set(id, newCamera);
    return newCamera;
  }

  async updateCamera(id: number, camera: Partial<InsertCamera>): Promise<Camera | undefined> {
    const existingCamera = this.cameras.get(id);
    if (!existingCamera) return undefined;

    const updatedCamera: Camera = { ...existingCamera, ...camera };
    this.cameras.set(id, updatedCamera);
    return updatedCamera;
  }

  async deleteCamera(id: number): Promise<boolean> {
    // First check if there are any camera streams associated with this camera
    const associatedStreams = Array.from(this.cameraStreams.values()).filter(
      stream => stream.cameraId === id
    );
    
    // Delete associated streams first
    for (const stream of associatedStreams) {
      this.cameraStreams.delete(stream.id);
    }
    
    return this.cameras.delete(id);
  }

  // Gateway operations
  async getAllGateways(): Promise<Gateway[]> {
    return Array.from(this.gateways.values());
  }

  async getGateway(id: number): Promise<Gateway | undefined> {
    return this.gateways.get(id);
  }

  async createGateway(gateway: InsertGateway): Promise<Gateway> {
    const id = this.gatewayIdCounter++;
    const newGateway: Gateway = { ...gateway, id };
    this.gateways.set(id, newGateway);
    return newGateway;
  }

  // Camera Stream operations
  async getAllCameraStreams(): Promise<CameraStream[]> {
    return Array.from(this.cameraStreams.values());
  }

  async getCameraStreamsByGateway(gatewayId: number): Promise<CameraStream[]> {
    return Array.from(this.cameraStreams.values()).filter(
      stream => stream.gatewayId === gatewayId
    );
  }

  async createCameraStream(cameraStream: InsertCameraStream): Promise<CameraStream> {
    const id = this.cameraStreamIdCounter++;
    
    // Create a properly typed CameraStream object
    const newCameraStream: CameraStream = {
      id,
      cameraId: cameraStream.cameraId,
      gatewayId: cameraStream.gatewayId === undefined ? null : cameraStream.gatewayId,
      streamIndex: cameraStream.streamIndex,
      throughput: cameraStream.throughput,
      storage: cameraStream.storage
    };
    
    this.cameraStreams.set(id, newCameraStream);
    return newCameraStream;
  }

  async updateCameraStreamGateway(id: number, gatewayId: number): Promise<CameraStream | undefined> {
    const existingStream = this.cameraStreams.get(id);
    if (!existingStream) return undefined;

    const updatedStream: CameraStream = { ...existingStream, gatewayId };
    this.cameraStreams.set(id, updatedStream);
    return updatedStream;
  }
}

export const storage = new MemStorage();

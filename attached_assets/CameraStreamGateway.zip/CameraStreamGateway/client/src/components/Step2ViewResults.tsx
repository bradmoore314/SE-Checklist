import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Calculations, GatewayConfiguration, GatewayType } from '@/types';
import { Router, ArrowLeft, ArrowRight } from 'lucide-react';

interface Step2ViewResultsProps {
  calculations: Calculations;
  gatewayConfig: GatewayConfiguration;
  onBackToStep1: () => void;
  onProceedToAssign: (config: GatewayConfiguration) => void;
}

export default function Step2ViewResults({
  calculations,
  gatewayConfig,
  onBackToStep1,
  onProceedToAssign
}: Step2ViewResultsProps) {
  const [selectedType, setSelectedType] = useState<GatewayType>(gatewayConfig.type);
  const [gatewayCount, setGatewayCount] = useState<number>(gatewayConfig.count);
  
  // Check if 8-channel gateway is a viable option
  const is8chViable = 
    calculations.totalStreams <= 8 && 
    calculations.totalThroughput <= 320 && 
    calculations.totalStorage <= 6;

  const handleProceed = () => {
    onProceedToAssign({
      type: selectedType,
      count: gatewayCount
    });
  };

  return (
    <div id="step2" className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Calculation Results</h3>
        <p className="mt-1 text-sm text-gray-600">Based on your camera specifications, here are the gateway requirements.</p>
      </div>
      
      <div className="p-6">
        {/* Results Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-blue-800 uppercase tracking-wide mb-1">Total Streams</h4>
            <div className="text-3xl font-bold text-blue-900">{calculations.totalStreams}</div>
            <p className="mt-1 text-sm text-blue-700">Total number of video streams across all cameras</p>
          </div>
          
          <div className="bg-indigo-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-indigo-800 uppercase tracking-wide mb-1">Total Throughput</h4>
            <div className="text-3xl font-bold text-indigo-900">{calculations.totalThroughput} MP/s</div>
            <p className="mt-1 text-sm text-indigo-700">Combined megapixels per second</p>
          </div>
          
          <div className="bg-purple-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-purple-800 uppercase tracking-wide mb-1">Total Storage</h4>
            <div className="text-3xl font-bold text-purple-900">{calculations.totalStorage.toFixed(2)} TB</div>
            <p className="mt-1 text-sm text-purple-700">Required storage capacity</p>
          </div>
        </div>
        
        {/* Gateway Recommendation */}
        <div className="bg-gradient-to-r from-primary to-secondary text-white p-6 rounded-lg mb-8">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <Router className="h-10 w-10" />
            </div>
            <div className="ml-4">
              <h4 className="text-xl font-bold mb-2">Recommended Gateway Configuration</h4>
              {gatewayConfig.type === '8ch' ? (
                <div id="singleGatewayRecommendation">
                  <p className="text-lg font-medium">1 × 8-channel Gateway</p>
                  <p className="text-sm opacity-90 mt-1">All your camera streams can fit within a single 8-channel gateway.</p>
                </div>
              ) : (
                <div id="multiGatewayRecommendation">
                  <p className="text-lg font-medium">{gatewayConfig.count} × 16-channel Gateway{gatewayConfig.count > 1 ? 's' : ''}</p>
                  <p className="text-sm opacity-90 mt-1">
                    Based on your throughput ({calculations.totalThroughput} MP/s) and storage requirements ({calculations.totalStorage.toFixed(2)} TB).
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Gateway Override */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
          <h4 className="text-lg font-medium text-gray-900 mb-4">Override Gateway Configuration</h4>
          <div className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Gateway Type</Label>
              <RadioGroup 
                defaultValue={selectedType} 
                onValueChange={(value) => setSelectedType(value as GatewayType)}
                className="space-y-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-10"
              >
                <div className="flex items-center">
                  <RadioGroupItem 
                    value="8ch" 
                    id="gateway8ch" 
                    disabled={!is8chViable}
                  />
                  <Label 
                    htmlFor="gateway8ch" 
                    className="ml-3 block text-sm font-medium text-gray-700"
                  >
                    8-channel Gateway (320 MP/s, 6 TB, 8 streams)
                  </Label>
                </div>
                <div className="flex items-center">
                  <RadioGroupItem value="16ch" id="gateway16ch" />
                  <Label 
                    htmlFor="gateway16ch" 
                    className="ml-3 block text-sm font-medium text-gray-700"
                  >
                    16-channel Gateway (640 MP/s, 12 TB, 16 streams)
                  </Label>
                </div>
              </RadioGroup>
            </div>
            
            <div>
              <Label htmlFor="gatewayCount" className="block text-sm font-medium text-gray-700">
                Number of Gateways
              </Label>
              <div className="mt-1 relative rounded-md shadow-sm max-w-xs">
                <Input 
                  type="number" 
                  min="1" 
                  value={gatewayCount} 
                  onChange={(e) => setGatewayCount(Math.max(1, parseInt(e.target.value) || 1))}
                  id="gatewayCount"
                  className="pr-12"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">units</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <div className="flex justify-end space-x-4">
              <Button 
                variant="outline" 
                onClick={onBackToStep1}
              >
                <ArrowLeft className="mr-1 h-4 w-4" /> Back
              </Button>
              <Button 
                onClick={handleProceed}
              >
                Continue <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

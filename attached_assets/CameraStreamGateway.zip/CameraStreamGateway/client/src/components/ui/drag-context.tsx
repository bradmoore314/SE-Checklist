import React, { createContext, useState, useContext, ReactNode } from 'react';
import { Stream } from '@/types';

type DragContextType = {
  draggedItem: Stream | null;
  setDraggedItem: (item: Stream | null) => void;
};

const DragContext = createContext<DragContextType | undefined>(undefined);

export function DragContextProvider({ children }: { children: ReactNode }) {
  const [draggedItem, setDraggedItem] = useState<Stream | null>(null);

  return (
    <DragContext.Provider value={{ draggedItem, setDraggedItem }}>
      {children}
    </DragContext.Provider>
  );
}

export function useDragContext() {
  const context = useContext(DragContext);
  if (context === undefined) {
    throw new Error('useDragContext must be used within a DragContextProvider');
  }
  return context;
}

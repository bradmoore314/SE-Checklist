import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Camera } from '@/types';
import { BITRATE_TABLE } from '@shared/schema';
import { Save, Plus, UsersRound, Info, Edit, Trash2, Calculator } from 'lucide-react';

// Form schema validation
const formSchema = z.object({
  name: z.string().optional(),
  lensCount: z.coerce.number().int().min(1).max(4),
  streamingResolution: z.coerce.number().int(),
  frameRate: z.coerce.number().int().min(1).max(60),
  storageDays: z.coerce.number().int().min(1).max(365),
  sameAsStreaming: z.boolean().default(true),
  recordingResolution: z.coerce.number().int().optional()
});

interface Step1AddCamerasProps {
  cameras: Camera[];
  setCameras: React.Dispatch<React.SetStateAction<Camera[]>>;
  cameraEditIndex: number;
  setCameraEditIndex: React.Dispatch<React.SetStateAction<number>>;
  onCalculate: () => void;
}

// Batch add form schema
const batchFormSchema = z.object({
  quantity: z.coerce.number().int().min(1).max(100),
  lensCount: z.coerce.number().int().min(1).max(4),
  streamingResolution: z.coerce.number().int(),
  frameRate: z.coerce.number().int().min(1).max(60),
  storageDays: z.coerce.number().int().min(1).max(365),
  sameAsStreaming: z.boolean().default(true),
  recordingResolution: z.coerce.number().int().optional(),
  namePrefix: z.string().optional()
});

export default function Step1AddCameras({
  cameras,
  setCameras,
  cameraEditIndex,
  setCameraEditIndex,
  onCalculate
}: Step1AddCamerasProps) {
  // State for batch add dialog
  const [isBatchDialogOpen, setIsBatchDialogOpen] = useState(false);
  
  // Initialize form with default values or editing camera values
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: cameraEditIndex >= 0 ? 
      {
        name: cameras[cameraEditIndex].name,
        lensCount: cameras[cameraEditIndex].lensCount,
        streamingResolution: cameras[cameraEditIndex].streamingResolution,
        frameRate: cameras[cameraEditIndex].frameRate,
        storageDays: cameras[cameraEditIndex].storageDays,
        sameAsStreaming: cameras[cameraEditIndex].recordingResolution === cameras[cameraEditIndex].streamingResolution,
        recordingResolution: cameras[cameraEditIndex].recordingResolution
      } : 
      {
        name: '',
        lensCount: 1,
        streamingResolution: 4,
        frameRate: 15,
        storageDays: 30,
        sameAsStreaming: true,
        recordingResolution: 4
      }
  });

  // Form submission handler
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Determine recording resolution based on checkbox
    const recordingResolution = values.sameAsStreaming ? 
      values.streamingResolution : 
      (values.recordingResolution || 1);
      
    // Auto-assign camera name if empty or not provided
    let cameraName = '';
    if (values.name) {
      cameraName = values.name.trim();
    }
    
    if (cameraName === '') {
      // For a new camera, number it as the next in sequence
      if (cameraEditIndex < 0) {
        cameraName = `Camera ${cameras.length + 1}`;
      } else {
        // For editing an existing camera, keep its original name if it had one
        cameraName = cameras[cameraEditIndex].name || `Camera ${cameraEditIndex + 1}`;
      }
    }
      
    const cameraData: Camera = {
      name: cameraName,
      lensCount: values.lensCount,
      streamingResolution: values.streamingResolution,
      frameRate: values.frameRate,
      storageDays: values.storageDays,
      recordingResolution: recordingResolution
    };
    
    if (cameraEditIndex >= 0) {
      // Update existing camera
      const updatedCameras = [...cameras];
      updatedCameras[cameraEditIndex] = cameraData;
      setCameras(updatedCameras);
      setCameraEditIndex(-1);
    } else {
      // Add new camera
      setCameras([...cameras, cameraData]);
    }
    
    // Reset form to defaults
    form.reset({
      name: '',
      lensCount: 1,
      streamingResolution: 4,
      frameRate: 15,
      storageDays: 30,
      sameAsStreaming: true,
      recordingResolution: 4
    });
  };

  // Calculate throughput and storage for a given camera
  const calculateCameraStats = (camera: Camera) => {
    const streamsPerCamera = camera.lensCount;
    const mpPerSecondPerStream = camera.streamingResolution * camera.frameRate;
    const totalMpPerSecond = mpPerSecondPerStream * streamsPerCamera;
    
    const bitrate = BITRATE_TABLE[camera.recordingResolution as keyof typeof BITRATE_TABLE];
    const storagePerStream = (86400 * camera.storageDays * bitrate) / 8000000;
    const totalStorage = storagePerStream * streamsPerCamera;
    
    return {
      totalMpPerSecond,
      totalStorage
    };
  };

  // Handle edit camera
  const handleEditCamera = (index: number) => {
    const camera = cameras[index];
    form.reset({
      name: camera.name,
      lensCount: camera.lensCount,
      streamingResolution: camera.streamingResolution,
      frameRate: camera.frameRate,
      storageDays: camera.storageDays,
      sameAsStreaming: camera.recordingResolution === camera.streamingResolution,
      recordingResolution: camera.recordingResolution
    });
    setCameraEditIndex(index);
    
    // Scroll to form
    document.getElementById('cameraForm')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Handle delete camera
  const handleDeleteCamera = (index: number) => {
    if (window.confirm('Are you sure you want to delete this camera?')) {
      const updatedCameras = [...cameras];
      updatedCameras.splice(index, 1);
      setCameras(updatedCameras);
      
      // If we're currently editing this camera, reset the edit state
      if (cameraEditIndex === index) {
        setCameraEditIndex(-1);
        form.reset({
          name: '',
          lensCount: 1,
          streamingResolution: 4,
          frameRate: 15,
          storageDays: 30,
          sameAsStreaming: true,
          recordingResolution: 4
        });
      } else if (cameraEditIndex > index) {
        // If we're editing a camera that comes after the deleted one, adjust the index
        setCameraEditIndex(cameraEditIndex - 1);
      }
    }
  };

  // Initialize batch form
  const batchForm = useForm<z.infer<typeof batchFormSchema>>({
    resolver: zodResolver(batchFormSchema),
    defaultValues: {
      quantity: 5,
      namePrefix: "Camera",
      lensCount: 1,
      streamingResolution: 4,
      frameRate: 15,
      storageDays: 30,
      sameAsStreaming: true,
      recordingResolution: 4
    }
  });

  // Handle batch add submission
  const onBatchSubmit = (values: z.infer<typeof batchFormSchema>) => {
    // Determine recording resolution based on checkbox
    const recordingResolution = values.sameAsStreaming ? 
      values.streamingResolution : 
      (values.recordingResolution || 1);
    
    // Create new cameras array
    const newCameras: Camera[] = [];
    const startIndex = cameras.length + 1;
    
    for (let i = 0; i < values.quantity; i++) {
      const cameraName = values.namePrefix ? 
        `${values.namePrefix.trim()} ${startIndex + i}` : 
        `Camera ${startIndex + i}`;
      
      newCameras.push({
        name: cameraName,
        lensCount: values.lensCount,
        streamingResolution: values.streamingResolution,
        frameRate: values.frameRate,
        storageDays: values.storageDays,
        recordingResolution: recordingResolution
      });
    }
    
    // Add all new cameras to the current list
    setCameras([...cameras, ...newCameras]);
    
    // Close dialog and reset form
    setIsBatchDialogOpen(false);
    batchForm.reset();
  };

  return (
    <div id="step1" className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Camera Specifications</h3>
        <p className="mt-1 text-sm text-gray-600">Enter details for each camera in your system.</p>
      </div>
      
      <div className="p-6">
        {/* Batch Add Dialog */}
        <Dialog open={isBatchDialogOpen} onOpenChange={setIsBatchDialogOpen}>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Add Multiple Cameras</DialogTitle>
              <DialogDescription>
                Quickly add multiple cameras with the same specifications.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...batchForm}>
              <form onSubmit={batchForm.handleSubmit(onBatchSubmit)} className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={batchForm.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Number of Cameras</FormLabel>
                        <FormControl>
                          <Input type="number" min={1} max={100} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={batchForm.control}
                    name="namePrefix"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Camera Name Prefix</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Building A Camera" {...field} />
                        </FormControl>
                        <FormDescription>
                          Will be numbered automatically
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <FormField
                    control={batchForm.control}
                    name="lensCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lens Count</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select lens count" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1">Single (1)</SelectItem>
                            <SelectItem value="2">Dual (2)</SelectItem>
                            <SelectItem value="4">Quad (4)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={batchForm.control}
                    name="streamingResolution"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Streaming Resolution</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select resolution" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1">1 MP</SelectItem>
                            <SelectItem value="2">2 MP</SelectItem>
                            <SelectItem value="4">4 MP</SelectItem>
                            <SelectItem value="5">5 MP</SelectItem>
                            <SelectItem value="6">6 MP</SelectItem>
                            <SelectItem value="8">8 MP</SelectItem>
                            <SelectItem value="12">12 MP</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={batchForm.control}
                    name="frameRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Frame Rate</FormLabel>
                        <FormControl>
                          <Input type="number" min={1} max={60} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={batchForm.control}
                  name="storageDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Days of Storage</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} max={365} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={batchForm.control}
                  name="sameAsStreaming"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Use same resolution for recording</FormLabel>
                        <FormDescription>
                          If unchecked, recording will use 1 MP resolution.
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsBatchDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Add Cameras</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        
        {/* Camera Form */}
        <Form {...form}>
          <form id="cameraForm" onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-12">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="sm:col-span-4">
                  <FormLabel>Camera Name (optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Front Door Camera" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="lensCount"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel className="required-field">Lens Count</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value.toString()}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select lens count" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">Single (1)</SelectItem>
                      <SelectItem value="2">Dual (2)</SelectItem>
                      <SelectItem value="4">Quad (4)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="streamingResolution"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel className="required-field whitespace-nowrap">Streaming Resolution</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value.toString()}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select resolution" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">1 MP</SelectItem>
                      <SelectItem value="2">2 MP</SelectItem>
                      <SelectItem value="4">4 MP</SelectItem>
                      <SelectItem value="5">5 MP</SelectItem>
                      <SelectItem value="6">6 MP</SelectItem>
                      <SelectItem value="8">8 MP</SelectItem>
                      <SelectItem value="12">12 MP</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="frameRate"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel className="required-field whitespace-nowrap">Frame Rate</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} max={60} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="storageDays"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel className="required-field whitespace-nowrap">Days of Storage</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} max={365} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="sameAsStreaming"
              render={({ field }) => (
                <FormItem className="sm:col-span-12 flex flex-row items-start space-x-3 space-y-0 rounded-md p-4">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Use same resolution for recording</FormLabel>
                    <FormDescription>
                      If unchecked, recording will use 1 MP resolution.
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
            
            <div className="sm:col-span-12 flex justify-between">
              <div className="text-sm text-gray-600">* Required fields</div>
              <div className="flex space-x-3">
                {cameraEditIndex < 0 && (
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => setIsBatchDialogOpen(true)}
                  >
                    <UsersRound className="mr-1 h-4 w-4" />
                    Add Multiple
                  </Button>
                )}
                <Button type="submit">
                  {cameraEditIndex >= 0 ? <Save className="mr-1 h-4 w-4" /> : <Plus className="mr-1 h-4 w-4" />} 
                  {cameraEditIndex >= 0 ? 'Update Camera' : 'Add Camera'}
                </Button>
              </div>
            </div>
          </form>
        </Form>
        
        {/* Camera List */}
        <div id="cameraListContainer" className="mt-8">
          <h4 className="text-lg font-medium text-gray-900 mb-4">Added Cameras</h4>
          
          {cameras.length === 0 ? (
            <div id="emptyCameraList" className="bg-blue-50 p-4 rounded-md">
              <div className="flex">
                <div className="flex-shrink-0">
                  <Info className="h-5 w-5 text-blue-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-blue-700">No cameras have been added yet. Use the form above to add your first camera.</p>
                </div>
              </div>
            </div>
          ) : (
            <div id="cameraList" className="mt-4 overflow-hidden border border-gray-200 rounded-md">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Camera</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lens Count</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Streaming</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Recording</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Frame Rate</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Storage</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Throughput</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Storage Req.</th>
                    <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {cameras.map((camera, index) => {
                    const stats = calculateCameraStats(camera);
                    return (
                      <tr key={index} className="camera-item hover:bg-gray-50">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{camera.name}</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {camera.lensCount === 1 ? 'Single (1)' : camera.lensCount === 2 ? 'Dual (2)' : 'Quad (4)'}
                          </div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{camera.streamingResolution} MP</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{camera.recordingResolution} MP</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{camera.frameRate} fps</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{camera.storageDays} days</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{stats.totalMpPerSecond} MP/s</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{stats.totalStorage.toFixed(2)} TB</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex justify-end space-x-2">
                            <button 
                              className="camera-edit-btn text-blue-600 hover:text-blue-800"
                              onClick={() => handleEditCamera(index)}
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button 
                              className="camera-delete-btn text-red-600 hover:text-red-800"
                              onClick={() => handleDeleteCamera(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
          
          <div className="mt-6 flex justify-between">
            {cameras.length > 0 && (
              <>
                <span id="cameraCount" className="text-sm font-medium text-gray-700">
                  Total cameras: <span>{cameras.length}</span>
                </span>
                <Button 
                  id="calculateBtn" 
                  onClick={onCalculate}
                  disabled={cameras.length === 0}
                >
                  <Calculator className="mr-1 h-4 w-4" /> Calculate Gateway Requirements
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

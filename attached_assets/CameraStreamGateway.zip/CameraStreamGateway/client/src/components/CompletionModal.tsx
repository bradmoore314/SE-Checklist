import React from 'react';
import { Button } from '@/components/ui/button';
import { Calculations, GatewayConfiguration } from '@/types';

interface CompletionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport: () => void;
  onStartOver: () => void;
  calculations: Calculations;
  totalCameras: number;
  gatewayConfig: GatewayConfiguration;
}

export default function CompletionModal({
  isOpen,
  onClose,
  onExport,
  onStartOver,
  calculations,
  totalCameras,
  gatewayConfig
}: CompletionModalProps) {
  if (!isOpen) return null;
  
  return (
    <div className="fixed z-10 inset-0 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
          <div>
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
              <span className="material-icons text-green-600">check</span>
            </div>
            <div className="mt-3 text-center sm:mt-5">
              <h3 className="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                Gateway Configuration Complete
              </h3>
              <div className="mt-2">
                <p className="text-sm text-gray-500">
                  Your gateway configuration has been successfully completed. Here's a summary of your setup:
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-4 bg-gray-50 p-4 rounded-md">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Configuration Summary</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Total Cameras: {totalCameras}</li>
              <li>• Total Streams: {calculations.totalStreams}</li>
              <li>• Total Throughput: {calculations.totalThroughput} MP/s</li>
              <li>• Total Storage: {calculations.totalStorage.toFixed(2)} TB</li>
              <li>• Gateways: {gatewayConfig.count} × {gatewayConfig.type === '8ch' ? '8' : '16'}-channel Gateway{gatewayConfig.count !== 1 ? 's' : ''}</li>
            </ul>
          </div>
          
          <div className="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
            <Button 
              onClick={onExport}
              className="sm:col-start-2"
            >
              Export Configuration
            </Button>
            <Button 
              variant="outline" 
              onClick={onStartOver}
              className="mt-3 sm:mt-0 sm:col-start-1"
            >
              Start Over
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

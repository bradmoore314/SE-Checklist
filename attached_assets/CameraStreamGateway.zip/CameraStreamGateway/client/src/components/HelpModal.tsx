import React from 'react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function HelpModal({ isOpen, onClose }: HelpModalProps) {
  if (!isOpen) return null;
  
  return (
    <div className="fixed z-10 inset-0 overflow-y-auto" aria-labelledby="help-modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full sm:p-6">
          <div className="absolute top-0 right-0 pt-4 pr-4">
            <button 
              type="button" 
              onClick={onClose}
              className="bg-white rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              <span className="sr-only">Close</span>
              <span className="material-icons">close</span>
            </button>
          </div>
          <div>
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-blue-100">
              <span className="material-icons text-blue-600">help</span>
            </div>
            <div className="mt-3 text-center sm:mt-5">
              <h3 className="text-lg leading-6 font-medium text-gray-900" id="help-modal-title">
                Gateway Calculator Help
              </h3>
            </div>
          </div>
          
          <div className="mt-4">
            <div className="space-y-6">
              <div>
                <h4 className="text-md font-medium text-gray-900">How to Use This Tool</h4>
                <p className="mt-1 text-sm text-gray-500">
                  This tool helps you calculate how many gateway devices you need for your camera system based on camera specifications.
                </p>
              </div>
              
              <div>
                <h4 className="text-md font-medium text-gray-900">Step 1: Add Cameras</h4>
                <ul className="mt-1 text-sm text-gray-500 list-disc pl-5 space-y-1">
                  <li>Enter each camera's details including lens count, resolution, frame rate, and storage requirements.</li>
                  <li>Add as many cameras as needed for your deployment.</li>
                </ul>
              </div>
              
              <div>
                <h4 className="text-md font-medium text-gray-900">Step 2: Review Results</h4>
                <ul className="mt-1 text-sm text-gray-500 list-disc pl-5 space-y-1">
                  <li>The calculator will recommend either 8-channel or 16-channel gateways based on your requirements.</li>
                  <li>You can override this recommendation if needed.</li>
                </ul>
              </div>
              
              <div>
                <h4 className="text-md font-medium text-gray-900">Step 3: Assign Cameras</h4>
                <ul className="mt-1 text-sm text-gray-500 list-disc pl-5 space-y-1">
                  <li>Drag and drop camera streams to assign them to specific gateways.</li>
                  <li>The tool will track throughput, storage, and stream counts for each gateway.</li>
                </ul>
              </div>
              
              <div>
                <h4 className="text-md font-medium text-gray-900">Gateway Limitations</h4>
                <ul className="mt-1 text-sm text-gray-500 list-disc pl-5 space-y-1">
                  <li><strong>8-channel Gateway:</strong> 320 MP/s throughput, 6 TB storage, 8 streams maximum</li>
                  <li><strong>16-channel Gateway:</strong> 640 MP/s throughput, 12 TB storage, 16 streams maximum</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mt-5 sm:mt-6">
            <button 
              type="button"
              onClick={onClose}
              className="w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:text-sm"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

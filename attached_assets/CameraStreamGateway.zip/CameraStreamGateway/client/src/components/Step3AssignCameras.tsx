import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Stream, GatewayConfiguration } from '@/types';
import { useDragContext } from '@/components/ui/drag-context';
import { 
  CheckCircle, 
  Sparkles, 
  GripVertical, 
  PlusCircle, 
  Eye, 
  ArrowDown, 
  ChevronDown, 
  CircleDashed, 
  MinusCircle, 
  ArrowUp, 
  ArrowLeft, 
  Check, 
  Info 
} from 'lucide-react';

interface Step3AssignCamerasProps {
  streams: Stream[];
  setStreams: React.Dispatch<React.SetStateAction<Stream[]>>;
  gatewayConfig: GatewayConfiguration;
  gatewayAssignments: {[gatewayId: string]: Stream[]};
  setGatewayAssignments: React.Dispatch<React.SetStateAction<{[gatewayId: string]: Stream[]}>>;
  onBackToStep2: () => void;
  onFinish: () => void;
  allStreamsAssigned: boolean;
}

// Generate a consistent color for each camera ID
const getCameraColorCode = (cameraId: string | number): string => {
  // Convert camera ID to a number
  const numericId = typeof cameraId === 'string' ? parseInt(cameraId) : cameraId;
  
  // Set of distinct colors for cameras
  const colors = [
    '#4F46E5', // indigo
    '#2563EB', // blue
    '#D946EF', // fuchsia
    '#EC4899', // pink
    '#EF4444', // red
    '#F59E0B', // amber
    '#10B981', // emerald
    '#0D9488', // teal
    '#8B5CF6', // violet
    '#6366F1', // indigo
    '#3B82F6', // blue
    '#0EA5E9', // sky
    '#14B8A6', // teal
    '#22C55E', // green
    '#84CC16', // lime
    '#EAB308', // yellow
  ];
  
  // Use modulo to cycle through colors for different camera IDs
  return colors[numericId % colors.length];
};

export default function Step3AssignCameras({
  streams,
  setStreams,
  gatewayConfig,
  gatewayAssignments,
  setGatewayAssignments,
  onBackToStep2,
  onFinish,
  allStreamsAssigned
}: Step3AssignCamerasProps) {
  const { draggedItem, setDraggedItem } = useDragContext();
  const [minimizedGateways, setMinimizedGateways] = useState<string[]>([]);
  const [gatewayOrder, setGatewayOrder] = useState<string[]>([]);
  
  // Initialize gateway order
  useEffect(() => {
    const initialOrder = Array.from({ length: gatewayConfig.count }).map((_, idx) => idx.toString());
    setGatewayOrder(initialOrder);
  }, [gatewayConfig.count]);

  const gatewayMaxStreams = gatewayConfig.type === '8ch' ? 8 : 16;
  const gatewayMaxThroughput = gatewayConfig.type === '8ch' ? 320 : 640;
  const gatewayMaxStorage = gatewayConfig.type === '8ch' ? 6 : 12;
  
  // Calculate current values for each gateway
  const getGatewayCurrentValues = (gatewayId: string) => {
    const gatewayStreams = gatewayAssignments[gatewayId] || [];
    const currentStreams = gatewayStreams.length;
    const currentThroughput = gatewayStreams.reduce((sum, stream) => sum + stream.throughput, 0);
    const currentStorage = gatewayStreams.reduce((sum, stream) => sum + stream.storage, 0);
    
    return {
      currentStreams,
      currentThroughput,
      currentStorage
    };
  };
  
  // Handle drag events
  const handleDragStart = (stream: Stream) => {
    setDraggedItem(stream);
  };
  
  const handleDragEnd = () => {
    setDraggedItem(null);
  };
  
  // Check if adding a stream (and all other streams from the same camera) to a gateway would exceed limits
  const wouldExceedLimits = (gatewayId: string, stream: Stream) => {
    const { currentStreams, currentThroughput, currentStorage } = getGatewayCurrentValues(gatewayId);
    
    // Find all unassigned streams from the same camera
    const cameraId = stream.cameraId;
    const unassignedCameraStreams = streams.filter(s => s.cameraId === cameraId);
    
    // Count how many streams would be added (all from the same camera)
    const totalStreamsToAdd = unassignedCameraStreams.length;
    const totalThroughputToAdd = unassignedCameraStreams.reduce((sum, s) => sum + s.throughput, 0);
    const totalStorageToAdd = unassignedCameraStreams.reduce((sum, s) => sum + s.storage, 0);
    
    // Check if the gateway already has other streams from the same camera - if so, we're not adding more
    const existingStreamsFromCamera = gatewayAssignments[gatewayId]?.filter(s => s.cameraId === cameraId) || [];
    if (existingStreamsFromCamera.length > 0) {
      return {
        streams: false,
        throughput: false,
        storage: false
      };
    }
    
    return {
      streams: currentStreams + totalStreamsToAdd > gatewayMaxStreams,
      throughput: currentThroughput + totalThroughputToAdd > gatewayMaxThroughput,
      storage: currentStorage + totalStorageToAdd > gatewayMaxStorage
    };
  };
  
  // Handle drop
  const handleDrop = (gatewayId: string, stream: Stream) => {
    // Find all streams from the same camera (both unassigned and in other gateways)
    const cameraId = stream.cameraId;
    const unassignedCameraStreams = streams.filter(s => s.cameraId === cameraId);
    
    // Check if this camera already has streams assigned to other gateways
    let streamsInOtherGateways: { streams: Stream[], gatewayId: string } | null = null;
    
    for (const gId in gatewayAssignments) {
      if (gId === gatewayId) continue; // Skip target gateway
      
      const streamsFromSameCamera = gatewayAssignments[gId].filter(s => s.cameraId === cameraId);
      if (streamsFromSameCamera.length > 0) {
        streamsInOtherGateways = { 
          streams: streamsFromSameCamera,
          gatewayId: gId
        };
        break;
      }
    }
    
    // If streams from this camera are already in another gateway, move them all to the new gateway
    if (streamsInOtherGateways) {
      // Collect all streams from this camera (both unassigned and from other gateways)
      const allCameraStreams = [...unassignedCameraStreams, ...streamsInOtherGateways.streams];
      
      // Check if the target gateway has enough capacity for all streams
      const totalStreams = allCameraStreams.length;
      const totalThroughput = allCameraStreams.reduce((sum, s) => sum + s.throughput, 0);
      const totalStorage = allCameraStreams.reduce((sum, s) => sum + s.storage, 0);
      
      const currentValues = getGatewayCurrentValues(gatewayId);
      
      if (currentValues.currentStreams + totalStreams > gatewayMaxStreams) {
        alert(`Cannot move all ${totalStreams} streams from this camera. Maximum of ${gatewayMaxStreams} streams per gateway.`);
        return;
      }
      
      if (currentValues.currentThroughput + totalThroughput > gatewayMaxThroughput) {
        alert(`Cannot move all streams from this camera. Total throughput of ${totalThroughput.toFixed(1)} MP/s exceeds gateway limit of ${gatewayMaxThroughput} MP/s.`);
        return;
      }
      
      if (currentValues.currentStorage + totalStorage > gatewayMaxStorage) {
        alert(`Cannot move all streams from this camera. Total storage of ${totalStorage.toFixed(1)} TB exceeds gateway limit of ${gatewayMaxStorage} TB.`);
        return;
      }
      
      // Update assignments
      const updatedAssignments = { ...gatewayAssignments };
      
      // Remove streams from old gateway
      if (streamsInOtherGateways) {
        updatedAssignments[streamsInOtherGateways.gatewayId] = updatedAssignments[streamsInOtherGateways.gatewayId]
          .filter(s => s.cameraId !== cameraId);
      }
      
      // Add all camera streams to new gateway
      updatedAssignments[gatewayId] = [...(updatedAssignments[gatewayId] || []), ...allCameraStreams];
      
      // Remove from unassigned streams
      const updatedStreams = streams.filter(s => s.cameraId !== cameraId);
      
      // Update state
      setGatewayAssignments(updatedAssignments);
      setStreams(updatedStreams);
    } 
    // Just unassigned streams to add
    else if (unassignedCameraStreams.length > 0) {
      // Check if the target gateway has enough capacity for all unassigned streams
      const totalStreams = unassignedCameraStreams.length;
      const totalThroughput = unassignedCameraStreams.reduce((sum, s) => sum + s.throughput, 0);
      const totalStorage = unassignedCameraStreams.reduce((sum, s) => sum + s.storage, 0);
      
      const currentValues = getGatewayCurrentValues(gatewayId);
      
      if (currentValues.currentStreams + totalStreams > gatewayMaxStreams) {
        alert(`Cannot add all ${totalStreams} streams from this camera. Maximum of ${gatewayMaxStreams} streams per gateway.`);
        return;
      }
      
      if (currentValues.currentThroughput + totalThroughput > gatewayMaxThroughput) {
        alert(`Cannot add all streams from this camera. Total throughput of ${totalThroughput.toFixed(1)} MP/s exceeds gateway limit of ${gatewayMaxThroughput} MP/s.`);
        return;
      }
      
      if (currentValues.currentStorage + totalStorage > gatewayMaxStorage) {
        alert(`Cannot add all streams from this camera. Total storage of ${totalStorage.toFixed(1)} TB exceeds gateway limit of ${gatewayMaxStorage} TB.`);
        return;
      }
      
      // Update assignments
      const updatedAssignments = { ...gatewayAssignments };
      
      // Add all unassigned camera streams to gateway
      updatedAssignments[gatewayId] = [...(updatedAssignments[gatewayId] || []), ...unassignedCameraStreams];
      
      // Remove from unassigned streams
      const updatedStreams = streams.filter(s => s.cameraId !== cameraId);
      
      // Update state
      setGatewayAssignments(updatedAssignments);
      setStreams(updatedStreams);
    }
  };
  
  // Handle moving a stream back to unassigned - move all streams from same camera
  const handleMoveBackToUnassigned = (stream: Stream, gatewayId: string) => {
    const cameraId = stream.cameraId;
    
    // Find all streams from the same camera in this gateway
    const cameraStreams = gatewayAssignments[gatewayId].filter(s => s.cameraId === cameraId);
    
    // Update assignments
    const updatedAssignments = { ...gatewayAssignments };
    updatedAssignments[gatewayId] = updatedAssignments[gatewayId].filter(s => s.cameraId !== cameraId);
    setGatewayAssignments(updatedAssignments);
    
    // Add all camera streams back to unassigned
    setStreams([...streams, ...cameraStreams]);
  };
  
  // Toggle gateway minimized state and move to end of list
  const handleMinimizeGateway = (gatewayId: string) => {
    // Add or remove from minimized list
    if (minimizedGateways.includes(gatewayId)) {
      setMinimizedGateways(minimizedGateways.filter(id => id !== gatewayId));
    } else {
      setMinimizedGateways([...minimizedGateways, gatewayId]);
      
      // Reorder gateways to move this one to the end
      const newOrder = gatewayOrder.filter(id => id !== gatewayId);
      newOrder.push(gatewayId);
      setGatewayOrder(newOrder);
    }
  };
  
  // Automatically assign all streams to gateways using a balanced algorithm
  const handleAutoAssign = () => {
    if (streams.length === 0) return; // Nothing to assign
    
    // Create a new assignments object
    const newAssignments = { ...gatewayAssignments };
    const gatewayIDs = Array.from({ length: gatewayConfig.count }, (_, i) => i.toString());
    
    // 1. Group streams by camera ID
    const cameraGroups: Record<string, Stream[]> = {};
    streams.forEach(stream => {
      if (!cameraGroups[stream.cameraId]) {
        cameraGroups[stream.cameraId] = [];
      }
      cameraGroups[stream.cameraId].push(stream);
    });
    
    // 2. Sort camera groups by total throughput (descending) to assign larger camera groups first
    const sortedCameraGroupIds = Object.keys(cameraGroups).sort((a, b) => {
      const aThroughput = cameraGroups[a].reduce((sum, s) => sum + s.throughput, 0);
      const bThroughput = cameraGroups[b].reduce((sum, s) => sum + s.throughput, 0);
      return bThroughput - aThroughput;
    });
    
    // 3. Prepare tracking for current gateway capacities
    const gatewayCapacity = gatewayIDs.reduce((acc, id) => {
      acc[id] = {
        currentStreams: newAssignments[id]?.length || 0,
        currentThroughput: newAssignments[id]?.reduce((sum, s) => sum + s.throughput, 0) || 0,
        currentStorage: newAssignments[id]?.reduce((sum, s) => sum + s.storage, 0) || 0
      };
      return acc;
    }, {} as Record<string, { currentStreams: number; currentThroughput: number; currentStorage: number }>);
    
    // 4. Keep track of streams we couldn't assign
    const unassignedStreams: Stream[] = [];
    
    // 5. Assign each camera group to a gateway - keeping all streams from the same camera together
    sortedCameraGroupIds.forEach(cameraId => {
      const cameraStreams = cameraGroups[cameraId];
      
      // Calculate total requirements for this camera group
      const totalStreams = cameraStreams.length;
      const totalThroughput = cameraStreams.reduce((sum, s) => sum + s.throughput, 0);
      const totalStorage = cameraStreams.reduce((sum, s) => sum + s.storage, 0);
      
      // Find the best gateway for this camera group
      let bestGatewayId: string | null = null;
      let maxAvailablePercentage = -1;
      
      for (const gatewayId of gatewayIDs) {
        const { currentStreams, currentThroughput, currentStorage } = gatewayCapacity[gatewayId];
        
        // Check if this gateway can accommodate all streams from this camera
        if (
          currentStreams + totalStreams <= gatewayMaxStreams &&
          currentThroughput + totalThroughput <= gatewayMaxThroughput &&
          currentStorage + totalStorage <= gatewayMaxStorage
        ) {
          // Calculate how much capacity (as a percentage) would be used after adding these streams
          const streamPercentage = (currentStreams + totalStreams) / gatewayMaxStreams;
          const throughputPercentage = (currentThroughput + totalThroughput) / gatewayMaxThroughput;
          const storagePercentage = (currentStorage + totalStorage) / gatewayMaxStorage;
          
          // Use the average of available percentages as a score
          const availablePercentage = 1 - ((streamPercentage + throughputPercentage + storagePercentage) / 3);
          
          // If this gateway has more available capacity, choose it
          if (availablePercentage > maxAvailablePercentage) {
            maxAvailablePercentage = availablePercentage;
            bestGatewayId = gatewayId;
          }
        }
      }
      
      // Assign all streams from this camera to the best gateway, or keep them unassigned
      if (bestGatewayId !== null) {
        newAssignments[bestGatewayId] = [...(newAssignments[bestGatewayId] || []), ...cameraStreams];
        
        // Update the gateway capacity
        gatewayCapacity[bestGatewayId].currentStreams += totalStreams;
        gatewayCapacity[bestGatewayId].currentThroughput += totalThroughput;
        gatewayCapacity[bestGatewayId].currentStorage += totalStorage;
      } else {
        // If the camera group doesn't fit any gateway, add all streams to unassigned
        unassignedStreams.push(...cameraStreams);
      }
    });
    
    // 6. Update the assignments and unassigned streams
    setGatewayAssignments(newAssignments);
    setStreams(unassignedStreams);
    
    // 7. Show a success message
    const totalAssignedStreams = streams.length - unassignedStreams.length;
    
    if (unassignedStreams.length === 0) {
      alert("All camera streams have been successfully assigned!");
    } else {
      const unassignedCameraIds = new Set(unassignedStreams.map(s => s.cameraId));
      alert(`${totalAssignedStreams} streams from ${sortedCameraGroupIds.length - unassignedCameraIds.size} cameras have been assigned. ${unassignedStreams.length} streams from ${unassignedCameraIds.size} cameras could not be assigned due to capacity constraints.`);
    }
  };

  return (
    <div id="step3" className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Assign Cameras to Gateways</h3>
        <p className="mt-1 text-sm text-gray-600">Drag and drop camera streams to allocate them to specific gateways.</p>
      </div>
      
      <div className="p-6">
        {/* Color Legend for Camera Groups */}
        <div className="bg-gray-50 p-3 rounded-lg mb-4 border border-gray-200">
          <p className="text-sm font-medium text-gray-700 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-sm align-middle mr-1"><circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4"></path><path d="M12 8h.01"></path></svg>
            Camera Grouping: Streams from the same camera are color-coded and will be kept together
          </p>
          <div className="flex flex-wrap gap-2">
            {/* Show first 8 colors as examples */}
            {Array.from({ length: 8 }).map((_, idx) => (
              <div key={idx} className="flex items-center">
                <div 
                  className="w-4 h-4 rounded-sm mr-1" 
                  style={{ backgroundColor: getCameraColorCode(idx) }}
                ></div>
                <span className="text-xs text-gray-600">Camera {idx + 1}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Camera Streams List - Left Side */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4">Unassigned Camera Streams</h4>
            <div 
              id="cameraStreamsForAssignment" 
              className="bg-gray-50 rounded-lg p-4 min-h-[600px] border border-gray-200 sticky top-0 overflow-y-auto"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (draggedItem && !streams.some(s => s.id === draggedItem.id)) {
                  // Find which gateway has this stream
                  for (const gatewayId in gatewayAssignments) {
                    const streamIndex = gatewayAssignments[gatewayId].findIndex(s => s.id === draggedItem.id);
                    if (streamIndex >= 0) {
                      handleMoveBackToUnassigned(draggedItem, gatewayId);
                      break;
                    }
                  }
                }
              }}
            >
              {streams.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <CheckCircle className="text-green-500 h-10 w-10 mb-2" />
                  <p className="text-gray-700 font-medium">All streams assigned!</p>
                  <p className="text-gray-500 text-center">All camera streams have been successfully assigned to gateways.</p>
                </div>
              ) : (
                <>
                  <div className="flex justify-between items-center mb-3">
                    <p className="text-gray-600">Drag any stream to a gateway on the right →</p>
                    <button
                      onClick={handleAutoAssign}
                      className="bg-blue-600 hover:bg-blue-700 text-white rounded-md px-3 py-1.5 text-sm flex items-center"
                    >
                      <Sparkles className="h-4 w-4 mr-1" />
                      Auto Assign
                    </button>
                  </div>
                  <div className="space-y-2">
                    {streams.map(stream => (
                      <div 
                        key={stream.id}
                        className="stream-item bg-white p-3 rounded-md shadow-sm border border-gray-200 hover:border-primary cursor-move flex items-center justify-between"
                        style={{
                          borderLeft: `4px solid ${getCameraColorCode(stream.cameraId)}`
                        }}
                        draggable
                        onDragStart={() => handleDragStart(stream)}
                        onDragEnd={handleDragEnd}
                      >
                        <div className="flex items-center">
                          <GripVertical className="text-gray-400 mr-2 h-4 w-4" />
                          <div>
                            <div className="font-medium text-gray-900">
                              {stream.name}
                              <span className="ml-2 text-xs py-0.5 px-1.5 bg-gray-100 text-gray-600 rounded">
                                Camera ID: {stream.cameraId}
                              </span>
                            </div>
                            <div className="text-xs text-gray-500">{stream.lensType} • {stream.resolution} • {stream.frameRate}</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span className="text-xs py-1 px-2 bg-blue-100 text-blue-800 rounded-full whitespace-nowrap">{stream.throughput} MP/s</span>
                          <span className="text-xs py-1 px-2 bg-indigo-100 text-indigo-800 rounded-full whitespace-nowrap">{stream.storage.toFixed(2)} TB</span>
                          <div className="flex">
                            {Array.from({ length: gatewayConfig.count }).map((_, idx) => {
                              const gatewayId = idx.toString();
                              // Check if adding this stream would exceed limits
                              const exceedsLimits = wouldExceedLimits(gatewayId, stream);
                              const canAdd = !exceedsLimits.streams && !exceedsLimits.throughput && !exceedsLimits.storage;
                              
                              return (
                                <button 
                                  key={idx}
                                  className={`ml-1 p-1 rounded-full ${canAdd ? 'text-green-600 hover:bg-green-100' : 'text-gray-400 cursor-not-allowed'}`}
                                  onClick={() => canAdd && handleDrop(gatewayId, stream)}
                                  title={canAdd ? `Add to Gateway ${idx + 1}` : `Cannot add to Gateway ${idx + 1} (exceeds limits)`}
                                  disabled={!canAdd}
                                >
                                  <PlusCircle className="h-4 w-4" />
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
          
          {/* Gateway Assignment Area - Right Side */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-lg font-medium text-gray-900">Gateways</h4>
              {minimizedGateways.length > 0 && (
                <button 
                  className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                  onClick={() => setMinimizedGateways([])}
                >
                  <Eye className="h-4 w-4 mr-1" />
                  Show All Gateways
                </button>
              )}
            </div>
            <div id="gatewaysContainer" className="space-y-4">
              {/* Active (non-minimized) gateways */}
              {gatewayOrder.map(gatewayId => {
                // Skip minimized gateways - they'll be shown in the minimized section
                if (minimizedGateways.includes(gatewayId)) {
                  return null;
                }
                
                const index = parseInt(gatewayId);
                const { currentStreams, currentThroughput, currentStorage } = getGatewayCurrentValues(gatewayId);
                
                // Calculate capacity percentages
                const streamPercentage = (currentStreams / gatewayMaxStreams) * 100;
                const throughputPercentage = (currentThroughput / gatewayMaxThroughput) * 100;
                const storagePercentage = (currentStorage / gatewayMaxStorage) * 100;
                
                return (
                  <div key={gatewayId} className="gateway-container transition-all duration-200">
                    <div className={`bg-gradient-to-r from-primary to-primary/90 text-white p-3 rounded-t-lg ${minimizedGateways.includes(gatewayId) ? 'opacity-70' : ''}`}>
                      <div className="flex justify-between items-center">
                        <h5 className="font-medium flex items-center text-shadow">
                          <span>Gateway {index + 1} ({gatewayConfig.type === '8ch' ? '8' : '16'}-channel)</span>
                          {currentStreams === gatewayMaxStreams && (
                            <span className="ml-2 bg-white bg-opacity-20 text-white text-xs py-0.5 px-2 rounded-full">Full</span>
                          )}
                        </h5>
                        <div className="flex space-x-1">
                          <button 
                            className="text-white hover:bg-white hover:bg-opacity-20 rounded p-1" 
                            title="Minimize Gateway"
                            onClick={() => handleMinimizeGateway(gatewayId)}
                          >
                            <ArrowDown className="h-4 w-4" />
                          </button>
                          <button 
                            className="text-white hover:bg-white hover:bg-opacity-20 rounded p-1" 
                            title="Expand/Collapse Gateway"
                            onClick={() => {
                              const gatewayContent = document.getElementById(`gateway-content-${gatewayId}`);
                              if (gatewayContent) {
                                gatewayContent.classList.toggle('hidden');
                              }
                            }}
                          >
                            <ChevronDown className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                      
                      <div className="mt-2 grid grid-cols-3 gap-2 text-xs text-shadow">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span>Streams:</span>
                            <span>{currentStreams}/{gatewayMaxStreams}</span>
                          </div>
                          <div className="w-full bg-white bg-opacity-20 rounded-full h-2">
                            <div className="bg-white rounded-full h-2" style={{ width: `${streamPercentage}%` }}></div>
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span>Throughput:</span>
                            <span>{currentThroughput.toFixed(0)}/{gatewayMaxThroughput}</span>
                          </div>
                          <div className="w-full bg-white bg-opacity-20 rounded-full h-2">
                            <div className="bg-white rounded-full h-2" style={{ width: `${throughputPercentage}%` }}></div>
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span>Storage:</span>
                            <span>{currentStorage.toFixed(1)}/{gatewayMaxStorage}</span>
                          </div>
                          <div className="w-full bg-white bg-opacity-20 rounded-full h-2">
                            <div className="bg-white rounded-full h-2" style={{ width: `${storagePercentage}%` }}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div 
                      id={`gateway-content-${gatewayId}`}
                      className="gateway-streams border-l border-r border-b border-gray-200 rounded-b-lg p-3 bg-white"
                      onDragOver={(e) => {
                        e.preventDefault();
                        e.currentTarget.classList.add('bg-blue-50', 'border-primary');
                      }}
                      onDragLeave={(e) => {
                        e.currentTarget.classList.remove('bg-blue-50', 'border-primary');
                      }}
                      onDrop={(e) => {
                        e.preventDefault();
                        e.currentTarget.classList.remove('bg-blue-50', 'border-primary');
                        if (draggedItem) {
                          handleDrop(gatewayId, draggedItem);
                        }
                      }}
                    >
                      {gatewayAssignments[gatewayId]?.length === 0 || !gatewayAssignments[gatewayId] ? (
                        <div className="text-center py-4 border-2 border-dashed border-gray-300 rounded-lg">
                          <p className="text-gray-500">
                            <CircleDashed className="h-6 w-6 block mx-auto mb-1" />
                            Drop camera streams here or use the quick-add buttons
                          </p>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {gatewayAssignments[gatewayId].map(stream => (
                            <div 
                              key={stream.id}
                              className="flex items-center justify-between bg-gray-50 p-2 rounded border border-gray-200 hover:border-primary cursor-move"
                              style={{
                                borderLeft: `4px solid ${getCameraColorCode(stream.cameraId)}`
                              }}
                              draggable
                              onDragStart={() => handleDragStart(stream)}
                              onDragEnd={handleDragEnd}
                            >
                              <div className="flex items-center">
                                <GripVertical className="text-gray-400 mr-1 h-3 w-3" />
                                <div>
                                  <div className="font-medium text-sm text-gray-900">
                                    {stream.name}
                                    <span className="ml-2 text-xs py-0.5 px-1.5 bg-gray-100 text-gray-600 rounded">
                                      Camera ID: {stream.cameraId}
                                    </span>
                                  </div>
                                  <div className="text-xs text-gray-500">{stream.lensType} • {stream.resolution}</div>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-xs py-0.5 px-1.5 bg-blue-100 text-blue-800 rounded-full">{stream.throughput}</span>
                                <span className="text-xs py-0.5 px-1.5 bg-indigo-100 text-indigo-800 rounded-full">{stream.storage.toFixed(1)}</span>
                                <button
                                  className="text-red-500 hover:text-red-700 p-1"
                                  onClick={() => handleMoveBackToUnassigned(stream, gatewayId)}
                                  title="Remove from gateway"
                                >
                                  <MinusCircle className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
              
              {/* Minimized Gateways Section */}
              {minimizedGateways.length > 0 && (
                <div className="mt-8 pt-4 border-t border-gray-200">
                  <h5 className="text-sm font-medium text-gray-700 mb-2">Minimized Gateways</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-2">
                    {minimizedGateways.map(gatewayId => {
                      const index = parseInt(gatewayId);
                      const { currentStreams, currentThroughput, currentStorage } = getGatewayCurrentValues(gatewayId);
                      
                      return (
                        <div 
                          key={`minimized-${gatewayId}`} 
                          className="bg-gray-100 p-2 rounded border border-gray-200 flex items-center justify-between"
                        >
                          <div>
                            <div className="text-sm font-medium text-gray-900">Gateway {index + 1}</div>
                            <div className="text-xs text-gray-500">
                              {currentStreams}/{gatewayMaxStreams} streams • {currentThroughput.toFixed(0)}/{gatewayMaxThroughput} MP/s
                            </div>
                          </div>
                          <button
                            className="text-blue-600 hover:text-blue-800 p-1"
                            onClick={() => handleMinimizeGateway(gatewayId)}
                            title="Restore Gateway"
                          >
                            <ArrowUp className="h-4 w-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200">
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={onBackToStep2}
            >
              <ArrowLeft className="mr-1 h-4 w-4" /> Back
            </Button>
            <Button 
              onClick={onFinish}
              disabled={!allStreamsAssigned}
              className={allStreamsAssigned ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-300 hover:bg-gray-400'}
            >
              <Check className="mr-1 h-4 w-4" /> Finish Configuration
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

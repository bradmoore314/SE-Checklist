import { Camera, Calculations } from '@/types';
import { BITRATE_TABLE } from '@shared/schema';

// Calculate the throughput and storage requirements for all cameras
export function calculateRequirements(cameras: Camera[]): Calculations {
  let totalStreams = 0;
  let totalThroughput = 0;
  let totalStorage = 0;
  
  cameras.forEach(camera => {
    const streamsPerCamera = camera.lensCount;
    totalStreams += streamsPerCamera;
    
    const mpPerSecondPerStream = camera.streamingResolution * camera.frameRate;
    totalThroughput += mpPerSecondPerStream * streamsPerCamera;
    
    const bitrate = BITRATE_TABLE[camera.recordingResolution as keyof typeof BITRATE_TABLE];
    const storagePerStream = (86400 * camera.storageDays * bitrate) / 8000000;
    totalStorage += storagePerStream * streamsPerCamera;
  });
  
  return {
    totalStreams,
    totalThroughput,
    totalStorage
  };
}

// Calculate how many 16-channel gateways are needed
export function calculateGatewaysNeeded(totalStreams: number, totalThroughput: number, totalStorage: number): number {
  const maxStreamsPerGateway = 16;
  const maxThroughputPerGateway = 640;
  const maxStoragePerGateway = 12;
  
  return Math.max(
    Math.ceil(totalStreams / maxStreamsPerGateway),
    Math.ceil(totalThroughput / maxThroughputPerGateway),
    Math.ceil(totalStorage / maxStoragePerGateway)
  );
}

// Calculate throughput for a single camera
export function calculateCameraThroughput(camera: Camera): number {
  return camera.streamingResolution * camera.frameRate * camera.lensCount;
}

// Calculate storage requirements for a single camera
export function calculateCameraStorage(camera: Camera): number {
  const bitrate = BITRATE_TABLE[camera.recordingResolution as keyof typeof BITRATE_TABLE];
  return (86400 * camera.storageDays * bitrate * camera.lensCount) / 8000000;
}

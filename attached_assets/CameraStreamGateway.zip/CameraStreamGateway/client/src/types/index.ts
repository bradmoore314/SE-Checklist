// Camera types
export interface Camera {
  name: string;
  lensCount: number;
  streamingResolution: number;
  frameRate: number;
  storageDays: number;
  recordingResolution: number;
}

// Stream types (represents a single lens output from a camera)
export interface Stream {
  id: string;
  name: string;
  lensType: string;
  resolution: string;
  frameRate: string;
  throughput: number;
  storage: number;
  cameraId: string; // Add cameraId to identify streams from the same camera
}

// Gateway types
export type GatewayType = '8ch' | '16ch';

export interface GatewayConfiguration {
  type: GatewayType;
  count: number;
}

// Calculation results
export interface Calculations {
  totalStreams: number;
  totalThroughput: number;
  totalStorage: number;
}

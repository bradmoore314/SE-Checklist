import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import GatewayCalculator from "@/components/GatewayCalculator";
import { DragContextProvider } from "@/components/ui/drag-context";

function Router() {
  return (
    <Switch>
      <Route path="/" component={GatewayCalculator} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <DragContextProvider>
        <Router />
        <Toaster />
      </DragContextProvider>
    </QueryClientProvider>
  );
}

export default App;
